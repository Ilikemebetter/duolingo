/********************************************************************************
** Form generated from reading UI file 'chooes.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHOOES_H
#define UI_CHOOES_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Chooes
{
public:
    QWidget *centralwidget;
    QPushButton *btnOption1;
    QPushButton *btnOption2;
    QPushButton *btnOption3;
    QPushButton *btnOption4;
    QLabel *label;
    QLabel *label_2;
    QLabel *lblQuestion;
    QLabel *lblResult;
    QLabel *lblTimeRemaining;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Chooes)
    {
        if (Chooes->objectName().isEmpty())
            Chooes->setObjectName("Chooes");
        Chooes->resize(806, 615);
        centralwidget = new QWidget(Chooes);
        centralwidget->setObjectName("centralwidget");
        btnOption1 = new QPushButton(centralwidget);
        btnOption1->setObjectName("btnOption1");
        btnOption1->setGeometry(QRect(120, 190, 251, 111));
        btnOption1->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 85, 0);\n"
"font: 16pt \"Imprint MT Shadow\";\n"
"color: rgb(255, 255, 255);"));
        btnOption2 = new QPushButton(centralwidget);
        btnOption2->setObjectName("btnOption2");
        btnOption2->setGeometry(QRect(430, 190, 251, 111));
        btnOption2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 85, 0);\n"
"font: 16pt \"Imprint MT Shadow\";\n"
"color: rgb(255, 255, 255);"));
        btnOption3 = new QPushButton(centralwidget);
        btnOption3->setObjectName("btnOption3");
        btnOption3->setGeometry(QRect(120, 350, 251, 111));
        btnOption3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 85, 0);\n"
"font: 16pt \"Imprint MT Shadow\";\n"
"color: rgb(255, 255, 255);"));
        btnOption4 = new QPushButton(centralwidget);
        btnOption4->setObjectName("btnOption4");
        btnOption4->setGeometry(QRect(430, 350, 251, 111));
        btnOption4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 85, 0);\n"
"font: 16pt \"Imprint MT Shadow\";\n"
"color: rgb(255, 255, 255);"));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(-80, 20, 1001, 741));
        label->setStyleSheet(QString::fromUtf8("image: url(:/res/Duolinga.jpg);"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(-200, 0, 1221, 641));
        label_2->setStyleSheet(QString::fromUtf8("image: url(:/res/backgr.jpg);"));
        lblQuestion = new QLabel(centralwidget);
        lblQuestion->setObjectName("lblQuestion");
        lblQuestion->setGeometry(QRect(240, 90, 321, 71));
        lblQuestion->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        lblQuestion->setStyleSheet(QString::fromUtf8("\n"
"text-decoration: underline;\n"
"font: 700 16pt \"Tahoma\";"));
        lblQuestion->setAlignment(Qt::AlignmentFlag::AlignCenter);
        lblResult = new QLabel(centralwidget);
        lblResult->setObjectName("lblResult");
        lblResult->setGeometry(QRect(290, 490, 211, 31));
        lblResult->setAlignment(Qt::AlignmentFlag::AlignCenter);
        lblTimeRemaining = new QLabel(centralwidget);
        lblTimeRemaining->setObjectName("lblTimeRemaining");
        lblTimeRemaining->setGeometry(QRect(30, 40, 101, 41));
        lblTimeRemaining->setStyleSheet(QString::fromUtf8("font: 900 9pt \"Cooper\";"));
        lblTimeRemaining->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        lblTimeRemaining->setLineWidth(1);
        lblTimeRemaining->setTextFormat(Qt::TextFormat::RichText);
        lblTimeRemaining->setAlignment(Qt::AlignmentFlag::AlignCenter);
        lblTimeRemaining->setTextInteractionFlags(Qt::TextInteractionFlag::NoTextInteraction);
        Chooes->setCentralWidget(centralwidget);
        label_2->raise();
        label->raise();
        btnOption1->raise();
        btnOption2->raise();
        btnOption3->raise();
        btnOption4->raise();
        lblQuestion->raise();
        lblResult->raise();
        lblTimeRemaining->raise();
        menubar = new QMenuBar(Chooes);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 806, 26));
        menubar->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        Chooes->setMenuBar(menubar);
        statusbar = new QStatusBar(Chooes);
        statusbar->setObjectName("statusbar");
        statusbar->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        Chooes->setStatusBar(statusbar);

        retranslateUi(Chooes);

        QMetaObject::connectSlotsByName(Chooes);
    } // setupUi

    void retranslateUi(QMainWindow *Chooes)
    {
        Chooes->setWindowTitle(QCoreApplication::translate("Chooes", "MainWindow", nullptr));
        btnOption1->setText(QCoreApplication::translate("Chooes", "Aws1", nullptr));
        btnOption2->setText(QCoreApplication::translate("Chooes", "Aws2", nullptr));
        btnOption3->setText(QCoreApplication::translate("Chooes", "Aws3", nullptr));
        btnOption4->setText(QCoreApplication::translate("Chooes", "Aws4", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        lblQuestion->setText(QString());
        lblResult->setText(QString());
#if QT_CONFIG(statustip)
        lblTimeRemaining->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(accessibility)
        lblTimeRemaining->setAccessibleName(QString());
#endif // QT_CONFIG(accessibility)
#if QT_CONFIG(accessibility)
        lblTimeRemaining->setAccessibleDescription(QString());
#endif // QT_CONFIG(accessibility)
        lblTimeRemaining->setText(QCoreApplication::translate("Chooes", "time count", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Chooes: public Ui_Chooes {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHOOES_H

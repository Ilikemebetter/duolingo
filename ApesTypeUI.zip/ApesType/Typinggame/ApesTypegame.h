#ifndef APESTYPEGAME_H
#define APESTYPEGAME_H

#include <QMainWindow>
#include <QTimer>
#include <QTime>
#include <QStringList>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; } // ✅ ให้แน่ใจว่าตรงกับไฟล์ UI
QT_END_NAMESPACE

class TypingGame : public QMainWindow // ✅ เปลี่ยนจาก QWidget เป็น QMainWindow
{
    Q_OBJECT

public:
    explicit TypingGame(QWidget *parent = nullptr);
    ~TypingGame();

private slots:
    void startGame();
    void checkInput(const QString &text);
    void updateTimer();
    void endGame();

private:
    Ui::MainWindow *ui;
    QTimer *timer;
    QTime startTime;
    QStringList texts;
    QString currentText;
    int mistakeCount;
};

#endif // APESTYPEGAME_H

#include "ApesTypegame.h"
#include "ui_ApesType.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QTime>
#include <QTimer>
#include <cstdlib>
#include <ctime>

TypingGame::TypingGame(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this); // โหลด UI
    srand(time(0));    // ตั้งค่า seed สำหรับ random

    // โหลดคำศัพท์จาก CSV
    QFile file(":/vocabulary_list.csv");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            texts << in.readLine();
        }
        file.close();
    } else {
        QMessageBox::warning(this, tr("Error"), tr("Failed to open CSV file!"));
    }

    // เชื่อมปุ่มและ input field กับฟังก์ชัน
    connect(ui->startButton, &QPushButton::clicked, this, &TypingGame::startGame);
    connect(ui->inputField, &QLineEdit::textChanged, this, &TypingGame::checkInput);

    // ตั้งค่า Timer
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &TypingGame::updateTimer);
}

TypingGame::~TypingGame() {
    delete ui;
}


void TypingGame::startGame() {
    if (texts.isEmpty()) {
        QMessageBox::warning(this, tr("Error"), tr("No words available!"));
        return;
    }

    int randomIndex = rand() % texts.size(); // สุ่มคำศัพท์
    currentText = texts[randomIndex];
    ui->textDisplay->setText(currentText);
    ui->inputField->setText("");
    ui->inputField->setEnabled(true);
    ui->inputField->setFocus();
    ui->resultDisplay->clear();
    mistakeCount = 0;

    startTime = QTime::currentTime();
    timer->start(100);
}

void TypingGame::checkInput(const QString &text) {
    if (text == currentText) {
        endGame();
    } else {
        if (currentText.startsWith(text)) {
            ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: green;");
        } else {
            ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: red;");
            mistakeCount++;
        }
    }
}

void TypingGame::updateTimer() {
    int elapsedTime = startTime.msecsTo(QTime::currentTime()) / 1000;
    ui->timerDisplay_2->setText(QString("Time: %1").arg(elapsedTime));
}

void TypingGame::endGame() {
    timer->stop();
    ui->inputField->setEnabled(false);

    int elapsedTime = startTime.msecsTo(QTime::currentTime()) / 1000;
    ui->resultDisplay->setText(QString("You finished in %1 seconds!\nMistakes: %2")
                                   .arg(elapsedTime)
                                   .arg(mistakeCount));
}

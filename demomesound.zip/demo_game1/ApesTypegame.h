#ifndef APESTYPEGAME_H
#define APESTYPEGAME_H

#include <QDialog>
#include <QTimer>
#include <QTime>
#include <QStringList>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

class ApesTypegame : public QDialog {  // เปลี่ยนจาก QWidget เป็น QDialog
    Q_OBJECT

public:
    explicit ApesTypegame(QWidget *parent = nullptr);  // เพิ่ม explicit และเปลี่ยนให้ตรงกับ QDialog
    ~ApesTypegame();

private slots:
    void startGame();
    void checkInput(const QString &text);
    void updateTimer();
    void endGame();

private:
    QLabel *textDisplay;
    QLabel *timerDisplay;
    QLabel *resultDisplay;
    QLineEdit *inputField;
    QPushButton *startButton;
    QTimer *timer;
    QTime startTime;
    QStringList texts;
    QString currentText;
    int mistakeCount;
    void setupUI();
    void setupGameGraphics();
};

#endif // APESTYPEGAME_H

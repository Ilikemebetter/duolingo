#ifndef APESTYPEGAME_H
#define APESTYPEGAME_H

#include <QTimer>
#include "ui_ApesTypegame.h"
#include <QVector>
#include <QString>
#include <QCloseEvent>  // สำหรับ QCloseEvent

QT_BEGIN_NAMESPACE
namespace Ui { class ApesTypegame; }
QT_END_NAMESPACE

class ApesTypegame : public QDialog {
    Q_OBJECT

public:
    explicit ApesTypegame(QWidget *parent = nullptr);
    ~ApesTypegame();

protected:
    void closeEvent(QCloseEvent *event) override;  // override closeEvent

private slots:
    void startGame();
    void checkInput(const QString &text);
    void updateTimer();
    void endGame();

private:
    Ui::ApesTypegame *ui;
    QTimer *timer;
    QVector<QString> texts;
    QString currentText;
    int countdownTime;
    int mistakeCount;
    int correctChars;
    int totalTypedChars;
};

#endif // APESTYPEGAME_H

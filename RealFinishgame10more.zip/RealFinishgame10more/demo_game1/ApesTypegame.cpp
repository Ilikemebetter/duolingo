#include "ApesTypegame.h"
#include "ui_ApesTypegame.h"
#include <QCoreApplication>
#include <QMessageBox>
#include <QTimer>
#include <QDebug>
#include <cstdlib>
#include <ctime>
#include <QFile>
#include <QKeyEvent>

ApesTypegame::ApesTypegame(QWidget *parent) : QDialog(parent),
    ui(new Ui::ApesTypegame)
{
    ui->setupUi(this);
    this->setWindowModality(Qt::ApplicationModal);
    setFixedSize(1200, 800);
    srand(time(0));
    countdownTime = 30;

    // อ่านคำศัพท์จากไฟล์ CSV
    QString filePath = QCoreApplication::applicationDirPath() + "/vocabulary_list.csv";
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            texts << in.readLine();
        }
        file.close();
    } else {
        QMessageBox::warning(this, tr("Error"), tr("Failed to open CSV file!"));
    }
    connect(ui->startButton, &QPushButton::clicked, this, &ApesTypegame::startGame);
    connect(ui->inputField, &QLineEdit::textChanged, this, &ApesTypegame::checkInput);
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &ApesTypegame::updateTimer);
}

ApesTypegame::~ApesTypegame() {
    delete ui;
}

void ApesTypegame::startGame() {
    if (texts.isEmpty()) {
        QMessageBox::warning(this, tr("Error"), tr("No words available!"));
        return;
    }
    int selectedTime = ui->timeSelector->value();
    if (selectedTime <= 0) {
        QMessageBox::warning(this, tr("Error"), tr("Please select a time before starting!"));
        return;
    }
    countdownTime = ui->timeSelector->value();
    ui->timerDisplay_2->setText(QString("Time: %1s").arg(countdownTime));

    int randomIndex = rand() % texts.size();
    currentText = texts[randomIndex];
    ui->textDisplay->setText(currentText);
    ui->inputField->setText("");
    ui->inputField->setEnabled(true);
    ui->inputField->setFocus();
    ui->resultDisplay->clear();
    ui->accuracyDisplay->clear();

    mistakeCount = 0;
    correctChars = 0;
    totalTypedChars = 0;

    ui->startButton->setEnabled(false);
    ui->inputField->setEnabled(true);
    timer->start(1000);
}

void ApesTypegame::checkInput(const QString &text) {
    if (!ui->inputField->isEnabled()) {
        return;
    }
    totalTypedChars++;
    if (text == currentText) {
        ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: green;");
        int randomIndex = rand() % texts.size();
        currentText = texts[randomIndex];
        ui->textDisplay->setText(currentText);
        ui->inputField->setText("");
        ui->inputField->setFocus();
        correctChars += text.length();
        totalTypedChars = 0;
        correctChars = 0;
    } else {
        if (currentText.startsWith(text)) {
            ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: green;");
            correctChars = text.length();
        } else {
            ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: red;");
            mistakeCount++;
        }
    }
    double acc = (totalTypedChars > 0) ? ((double)correctChars / totalTypedChars) * 100 : 0;
    ui->accuracyDisplay->setText(QString("Accuracy: %1%").arg(acc, 0, 'f', 2));
}

void ApesTypegame::updateTimer() {
    countdownTime--;
    ui->timerDisplay_2->setText(QString("Time: %1s").arg(countdownTime));
    if (countdownTime <= 0) {
        endGame();
    }
}

void ApesTypegame::endGame() {
    timer->stop();
    ui->inputField->setEnabled(false);
    ui->startButton->setEnabled(true);
    double acc = (totalTypedChars > 0) ? ((double)correctChars / totalTypedChars) * 100 : 0;
    ui->resultDisplay->setText(QString("Game Over!\nMistakes: %1").arg(mistakeCount));
    ui->accuracyDisplay->setText(QString("Accuracy: %1%").arg(acc, 0, 'f', 2));
}

// เพิ่มฟังก์ชัน closeEvent เพื่อหยุด timer และทำลาย instance
void ApesTypegame::closeEvent(QCloseEvent *event) {
    if (timer->isActive()) {
        timer->stop();
    }
    event->accept();
    deleteLater();  // ทำลาย instance หลังจากปิดหน้าต่าง
}

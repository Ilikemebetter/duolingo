#include "ApesTypegame.h"
#include "ui_ApesType.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QTimer>
#include <cstdlib>
#include <ctime>
#include <QKeyEvent>

TypingGame::TypingGame(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    srand(time(0));

    countdownTime = 30; // ตั้งค่าเริ่มต้น 30 วินาที

    // โหลดคำศัพท์จาก CSV
    QFile file(":/vocabulary_list.csv");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            texts << in.readLine();
        }
        file.close();
    } else {
        QMessageBox::warning(this, tr("Error"), tr("Failed to open CSV file!"));
    }

    // เชื่อมปุ่มและ input field กับฟังก์ชัน
    connect(ui->startButton, &QPushButton::clicked, this, &TypingGame::startGame);
    connect(ui->inputField, &QLineEdit::textChanged, this, &TypingGame::checkInput);

    // ตั้งค่า Timer
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &TypingGame::updateTimer);
}

TypingGame::~TypingGame() {
    delete ui;
}

void TypingGame::startGame() {
    if (texts.isEmpty()) {
        QMessageBox::warning(this, tr("Error"), tr("No words available!"));
        return;
    }

    // รับค่าจาก timeSelector และตั้งค่าถอยหลัง
    countdownTime = ui->timeSelector->value();
    ui->timerDisplay_2->setText(QString("Time: %1s").arg(countdownTime));

    // เริ่มต้นด้วยคำแรกจาก texts
    int randomIndex = rand() % texts.size();
    currentText = texts[randomIndex];
    ui->textDisplay->setText(currentText);
    ui->inputField->setText("");
    ui->inputField->setEnabled(true);
    ui->inputField->setFocus();
    ui->resultDisplay->clear();
    ui->accuracyDisplay->clear();

    mistakeCount = 0;
    correctChars = 0;

    // ปิดปุ่ม Start เมื่อเกมเริ่ม
    ui->startButton->setEnabled(false);

    timer->start(1000); // เริ่มจับเวลา
}

void TypingGame::checkInput(const QString &text) {
    totalTypedChars++; // เพิ่มตัวนับจำนวนตัวอักษรที่พิมพ์ทั้งหมด

    if (text == currentText) {
        ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: green;");

        // เมื่อพิมพ์คำถูกต้องแล้ว ให้สุ่มคำใหม่จาก texts
        int randomIndex = rand() % texts.size();
        currentText = texts[randomIndex];
        ui->textDisplay->setText(currentText); // แสดงคำใหม่
        ui->inputField->setText("");          // เคลียร์ช่องกรอกข้อความ
        ui->inputField->setFocus();           // ตั้งให้ช่องกรอกข้อความเป็นโฟกัสใหม่

        // เพิ่มคะแนนที่ถูกต้อง
        correctChars += text.length(); // เพิ่มตัวอักษรที่ถูกต้อง
    } else {
        if (currentText.startsWith(text)) {
            ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: green;");
            correctChars = text.length(); // นับจำนวนตัวอักษรถูกต้อง
        } else {
            ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: red;");
            mistakeCount++;
        }
    }

    // คำนวณ accuracy ทุกครั้งหลังจากพิมพ์ข้อความ
    double acc = (totalTypedChars > 0) ? ((double)correctChars / totalTypedChars) * 100 : 0;
    ui->accuracyDisplay->setText(QString("Accuracy: %1%").arg(acc, 0, 'f', 2)); // แสดง accuracy
}


void TypingGame::updateTimer() {
    countdownTime--; // ลดเวลาถอยหลัง
    ui->timerDisplay_2->setText(QString("Time: %1s").arg(countdownTime));

    if (countdownTime <= 0) {
        endGame(); // จบเกมเมื่อหมดเวลา
    }
}

void TypingGame::endGame() {
    timer->stop();
    ui->inputField->setEnabled(false);
    ui->startButton->setEnabled(true);  // เปิดปุ่ม Start

    // คำนวณ accuracy เมื่อเกมจบ
    double acc = (totalTypedChars > 0) ? ((double)correctChars / totalTypedChars) * 100 : 0;

    ui->resultDisplay->setText(QString("Game Over!\nMistakes: %1").arg(mistakeCount));
    ui->accuracyDisplay->setText(QString("Accuracy: %1%").arg(acc, 0, 'f', 2)); // แสดง accuracy เมื่อเกมจบ
}



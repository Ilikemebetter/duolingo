#ifndef APESTYPEGAME_H
#define APESTYPEGAME_H

#include <QMainWindow>
#include <QTimer>
#include <QVector>
#include <QString>


namespace Ui {
class MainWindow;
}

class TypingGame : public QMainWindow {
    Q_OBJECT

public:
    explicit TypingGame(QWidget *parent = nullptr);
    ~TypingGame();

private slots:
    void startGame();
    void checkInput(const QString &text);
    void updateTimer();
    void endGame();


private:
    Ui::MainWindow *ui;
    QTimer *timer;
    QVector<QString> texts;
    QString currentText;
    int countdownTime;
    int mistakeCount;
    int correctChars;
    int totalTypedChars;
};

#endif // APESTYPEGAME_H

#include "ApesTypegame.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QMainWindow *window = new TypingGame(); // ✅ ใช้ QMainWindow
    window->show();

    return a.exec();
}

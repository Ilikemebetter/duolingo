#include "menu.h"
#include "ui_menu.h"
#include <QMessageBox>
#include <QDebug>

Menu::Menu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Menu)
{
    ui->setupUi(this);
    qDebug() << "Menu Created"; //debug menu page
    connect(ui->BtnToGameChoose, &QPushButton::clicked, this, &Menu::on_BtnToGameChoose_clicked);
}

Menu::~Menu()
{
    delete ui;
}


void Menu::on_BtnToGameChoose_clicked()
{
    QMessageBox::information(this, "Game 1","ได้แล้ว");
}

void Menu::on_BtnToGameFlashcard_clicked()
{
    QMessageBox::information(this, "Game 2","ได้แล้ว");
}


void Menu::on_BtnToGameApestype_clicked()
{
    QMessageBox::information(this, "Game 3","ได้แล้ว");
}


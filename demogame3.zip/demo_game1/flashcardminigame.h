#ifndef FLASHCARDMINIGAME_H
#define FLASHCARDMINIGAME_H

#include <QWidget>
#include <QList>
#include <QPair>
#include <QMediaPlayer>
#include <QAudioOutput>

namespace Ui {
class flashcardminigame;
}

class FlashcardMiniGame : public QWidget
{
    Q_OBJECT

public:
    explicit FlashcardMiniGame(QWidget *parent = nullptr);
    ~FlashcardMiniGame();

private slots:
    void handleNext();

private:
    Ui::flashcardminigame *ui;
    QList<QPair<QString, QString>> flashcards; // แต่ละ flashcard เป็นคู่ (word, meaning)
    int currentRound;
    const int totalRounds = 5;
    int correctCount;
    int wrongCount;
    QString correctAnswer;

    void loadFlashcards();
    void setupRound();

    QMediaPlayer *Soundgame;
    QAudioOutput *audioOutput;
};

#endif // FLASHCARDMINIGAME_H

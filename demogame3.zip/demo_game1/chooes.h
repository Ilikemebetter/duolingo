#ifndef CHOOES_H
#define CHOOES_H

#include <QMainWindow>
#include <QVector>
#include <QString>
#include <QTimer>
#include <QMediaPlayer>
#include <QAudioOutput>


QT_BEGIN_NAMESPACE
namespace Ui { class Chooes; }
QT_END_NAMESPACE

struct Question {
    QString meaning;        // ความหมายของคำศัพท์
    QVector<QString> options; // ตัวเลือก 4 ข้อ
    int correctIndex;        // ตำแหน่งของคำตอบที่ถูกต้อง
};

class Chooes : public QMainWindow {
    Q_OBJECT

public:
    Chooes(QWidget *parent = nullptr);
    ~Chooes();

private slots:
    void loadQuestionsFromCSV(); // โหลดคำศัพท์จาก CSV
    void generateQuestion(); // สุ่มคำถาม
    void checkAnswer(); // ตรวจสอบคำตอบ
    void nextQuestion(); // ไปยังคำถามถัดไป
    void updateTimer(); //ตัวจับเวลา

private:
    Ui::Chooes *ui;
    QVector<QPair<QString, QString>> vocabularyList; // เก็บ word และ meaning
    Question currentQuestion; // คำถามปัจจุบัน
    int wrongAnswersCount;        // จำนวนข้อที่ผิด
    QTimer *quizTimer;            // ตัวจับเวลา
    int timeRemaining;            // เวลาที่เหลือ
    QMediaPlayer *countdownSound;
    QAudioOutput *audioOutput;
};


#endif // CHOOES_H

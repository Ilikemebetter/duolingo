#include "menu.h"
#include "ui_menu.h"
#include <QMessageBox>
#include <QDebug>

Menu::Menu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Menu),
    chooesGame(nullptr)
{
    ui->setupUi(this);
    qDebug() << "Menu Created"; //debug menu page
    connect(ui->BtnToGameChoose, &QPushButton::clicked, this, &Menu::on_BtnToGameChoose_clicked);
}

Menu::~Menu()
{
    delete ui;
}


void Menu::on_BtnToGameChoose_clicked()
{
    if (!chooesGame) {  // ถ้ายังไม่ได้สร้าง ให้สร้างขึ้นมา
        chooesGame = new Chooes(this);
    }
    chooesGame->show();  // เปิดหน้าของเกม
}

void Menu::on_BtnToGameFlashcard_clicked()
{
    QMessageBox::information(this, "Game 2","ได้แล้ว");
}


void Menu::on_BtnToGameApestype_clicked()
{
    QMessageBox::information(this, "Game 3","ได้แล้ว");
}


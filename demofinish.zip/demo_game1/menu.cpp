#include "menu.h"
#include "ui_menu.h"
#include <QMessageBox>
#include <QDebug>

Menu::Menu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Menu),
    chooesGame(nullptr),
    FlashcardGame(nullptr),
    ApesTypeGame(nullptr)
{
    ui->setupUi(this);
    qDebug() << "Menu Created"; //debug menu page
    connect(ui->BtnToGameChoose, &QPushButton::clicked, this, &Menu::on_BtnToGameChoose_clicked);
    connect(ui->BtnToGameFlashcard, &QPushButton::clicked, this, &Menu::on_BtnToGameFlashcard_clicked);
    connect(ui->BtnToGameApestype, &QPushButton::clicked, this, &Menu::on_BtnToGameApestype_clicked);
}


Menu::~Menu()
{
    delete ui;
}


void Menu::on_BtnToGameChoose_clicked()
{
    if (!chooesGame) {  // ถ้ายังไม่ได้สร้าง ให้สร้างขึ้นมา
        chooesGame = new Chooes(this);
    }
    chooesGame->show();  // เปิดหน้าของเกม
}

void Menu::on_BtnToGameFlashcard_clicked()
{
    if (!FlashcardGame) {  // ถ้ายังไม่ได้สร้าง ให้สร้างขึ้นมา
        FlashcardGame = new FlashcardInput(this);
    }
    FlashcardGame->show();  // เปิดหน้าของเกม
}


void Menu::on_BtnToGameApestype_clicked()
{
    if (!ApesTypeGame) {  // ถ้ายังไม่ได้สร้าง ให้สร้างขึ้นมา
        ApesTypeGame = new ApesTypegame(this);
    }
    ApesTypeGame->show();  // เปิดหน้าของเกมQMessageBox::information(this, "Game 3","ได้แล้ว");
}


#include "flashcardminigame.h"
#include "ui_flashcardminigame.h"
#include "flashcardresult.h"
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>
#include <QMessageBox>
#include <QRandomGenerator>
#include <QTimer>
#include <QPushButton>
#include <algorithm>

FlashcardMiniGame::FlashcardMiniGame(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::flashcardminigame),
    currentRound(0),
    correctCount(0),
    wrongCount(0)
{
    ui->setupUi(this);
    // Soundgame = new QMediaPlayer(this);
    // audioOutput = new QAudioOutput(this);
    // Soundgame->setAudioOutput(audioOutput);
    // Soundgame->setSource(QUrl("qrc:/bgtrack/americanpatrol.ogg"));
    // audioOutput->setVolume(0.7);
    // Soundgame->play();
    loadFlashcards();
    if (flashcards.isEmpty()) {
        QMessageBox::critical(this, "Error", "No flashcards available. Please add some words first.");
        close();
        return;
    }
    // เชื่อมต่อปุ่ม NextButton กับ slot handleNext()
    connect(ui->NextButton, &QPushButton::clicked, this, &FlashcardMiniGame::handleNext);

    // เริ่มรอบแรก
    setupRound();
}

FlashcardMiniGame::~FlashcardMiniGame()
{
    delete ui;
    //delete Soundgame;
    //delete audioOutput;
}

void FlashcardMiniGame::loadFlashcards()
{
    // โหลด flashcard จากไฟล์ CSV ในโฟลเดอร์โปรแกรม
    QString filePath = QCoreApplication::applicationDirPath() + "/vocabulary_list.csv";
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty())
            continue;
        QStringList parts = line.split(",");
        if (parts.size() >= 2)
            flashcards.append(qMakePair(parts[0].trimmed(), parts[1].trimmed()));
    }
    file.close();
}

void FlashcardMiniGame::setupRound()
{
    // อัปเดตแสดงรอบที่กำลังเล่นอยู่
    ui->gameProgress->setText(QString("Round %1 of %2").arg(currentRound + 1).arg(totalRounds));

    // เลือก flashcard แบบสุ่มมาใช้งาน
    int idx = QRandomGenerator::global()->bounded(flashcards.size());
    QPair<QString, QString> currentCard = flashcards.at(idx);
    ui->wordLabel->setText(currentCard.first);
    correctAnswer = currentCard.second;


    // เคลียร์ QLineEdit สำหรับให้ผู้ใช้พิมพ์คำตอบและลบข้อความ feedback
    ui->Writethisline->clear();
    ui->feedbackLabel->setText("");
}
void FlashcardMiniGame::handleNext()
{
    // ปิดปุ่ม Next ทันทีเพื่อป้องกันการกดซ้ำ
    ui->NextButton->setEnabled(false);

    QString userAnswer = ui->Writethisline->text().trimmed();
    if (userAnswer.compare(correctAnswer, Qt::CaseInsensitive) == 0) {
        correctCount++;
        ui->feedbackLabel->setText("✔ Correct!");
    } else {
        wrongCount++;
        ui->feedbackLabel->setText("✘ Incorrect! Correct answer: " + correctAnswer);
    }

    currentRound++;

    // หน่วงเวลา 1 วินาทีเพื่อให้ feedback แสดงก่อนเริ่มรอบใหม่หรือปิดเกม
    QTimer::singleShot(1000, this, [this]() {
        if (currentRound >= totalRounds) {
            // ถ้าครบจำนวนรอบ ให้สร้างหน้าผลลัพธ์แล้วปิดหน้ามินิเกม
            //Soundgame->stop();
            FlashcardResult *result = new FlashcardResult(correctCount, wrongCount);
            result->show();
            this->close();
        } else {
            // เริ่มรอบใหม่และเปิดใช้งานปุ่ม Next อีกครั้ง
            setupRound();
            ui->NextButton->setEnabled(true);
        }
    });
}


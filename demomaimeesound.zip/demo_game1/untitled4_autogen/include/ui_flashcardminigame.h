/********************************************************************************
** Form generated from reading UI file 'flashcardminigame.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FLASHCARDMINIGAME_H
#define UI_FLASHCARDMINIGAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_flashcardminigame
{
public:
    QLabel *gameProgress;
    QLabel *wordLabel;
    QLabel *Writemeaning;
    QLabel *feedbackLabel;
    QLineEdit *Writethisline;
    QPushButton *NextButton;

    void setupUi(QWidget *flashcardminigame)
    {
        if (flashcardminigame->objectName().isEmpty())
            flashcardminigame->setObjectName("flashcardminigame");
        flashcardminigame->resize(640, 480);
        gameProgress = new QLabel(flashcardminigame);
        gameProgress->setObjectName("gameProgress");
        gameProgress->setGeometry(QRect(280, 80, 81, 16));
        wordLabel = new QLabel(flashcardminigame);
        wordLabel->setObjectName("wordLabel");
        wordLabel->setGeometry(QRect(80, 100, 61, 16));
        Writemeaning = new QLabel(flashcardminigame);
        Writemeaning->setObjectName("Writemeaning");
        Writemeaning->setGeometry(QRect(80, 130, 91, 16));
        feedbackLabel = new QLabel(flashcardminigame);
        feedbackLabel->setObjectName("feedbackLabel");
        feedbackLabel->setGeometry(QRect(110, 220, 261, 16));
        Writethisline = new QLineEdit(flashcardminigame);
        Writethisline->setObjectName("Writethisline");
        Writethisline->setGeometry(QRect(80, 160, 401, 24));
        NextButton = new QPushButton(flashcardminigame);
        NextButton->setObjectName("NextButton");
        NextButton->setGeometry(QRect(400, 220, 80, 24));

        retranslateUi(flashcardminigame);

        QMetaObject::connectSlotsByName(flashcardminigame);
    } // setupUi

    void retranslateUi(QWidget *flashcardminigame)
    {
        flashcardminigame->setWindowTitle(QCoreApplication::translate("flashcardminigame", "Form", nullptr));
        gameProgress->setText(QCoreApplication::translate("flashcardminigame", "GameProhress", nullptr));
        wordLabel->setText(QCoreApplication::translate("flashcardminigame", "WordLabel", nullptr));
        Writemeaning->setText(QCoreApplication::translate("flashcardminigame", "Write meaning", nullptr));
        feedbackLabel->setText(QCoreApplication::translate("flashcardminigame", "FeedBack", nullptr));
        NextButton->setText(QCoreApplication::translate("flashcardminigame", "Next", nullptr));
    } // retranslateUi

};

namespace Ui {
    class flashcardminigame: public Ui_flashcardminigame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FLASHCARDMINIGAME_H

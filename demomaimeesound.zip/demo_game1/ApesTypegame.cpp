#include "ApesTypegame.h"
#include "ui_ApesTypegame.h"
#include <QCoreApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QTime>
#include <QTimer>
#include <QStringList>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QDebug>
#include <cstdlib>
#include <ctime>
#include <QFile>
#include <QTextStream>

ApesTypegame::ApesTypegame(QWidget *parent) : QDialog(parent)
    , ui(new Ui::ApesTypegame)
{
    ui->setupUi(this);
    setFixedSize(1200, 800); // ตั้งค่าขนาดหน้าต่าง
    srand(time(0)); // ตั้งค่า seed สำหรับ rand
    // bgSound = new QMediaPlayer(this);
    // audioOutput = new QAudioOutput(this);
    // bgSound->setAudioOutput(audioOutput);
    // bgSound->setSource(QUrl("qrc:/bgtrack/fight_looped.ogg"));
    // audioOutput->setVolume(0.7); // ตั้งระดับเสียง
    // bgSound->play();

    // อ่านคำศัพท์จากไฟล์ CSV
    QString filePath = QCoreApplication::applicationDirPath() + "/vocabulary_list.csv";
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            texts << in.readLine();
            //QString line = in.readLine();
            //texts << line; // เพิ่มคำศัพท์ลงในลิสต์
        }
        file.close();
    } else {
        QMessageBox::warning(this, tr("Error"), tr("Failed to open CSV file!"));
    }
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &ApesTypegame::updateTimer);
    connect(ui->startButton, &QPushButton::clicked, this, &ApesTypegame::startGame);
    connect(ui->inputField, &QLineEdit::textChanged, this, &ApesTypegame::checkInput);
}

ApesTypegame::~ApesTypegame() {
    delete ui;  // ✅ ลบ ui เมื่อปิด Dialog
    //delete bgSound;
    //delete audioOutput;
}

void ApesTypegame::startGame() {
    if (texts.isEmpty()) {
        QMessageBox::warning(this, tr("Error"), tr("No words available!"));
        return;
    }

    int randomIndex = rand() % texts.size();
    currentText = texts[randomIndex];
    ui->textDisplay->setText(currentText);  // ✅ ใช้ ui-> เข้าถึง Widget
    ui->inputField->setText("");
    ui->inputField->setEnabled(true);
    ui->inputField->setFocus();
    ui->resultDisplay->clear();
    mistakeCount = 0;

    startTime = QTime::currentTime();
    timer->start(100);
}

void ApesTypegame::checkInput(const QString &text) {
    if (text == currentText) {
        endGame();
    } else {
        if (currentText.startsWith(text)) {
            ui->inputField->setStyleSheet("color: green;");
        } else {
            ui->inputField->setStyleSheet("color: red;");
            mistakeCount++;
        }
    }
}
void ApesTypegame::updateTimer() {
    int elapsedTime = startTime.msecsTo(QTime::currentTime()) / 1000;
    ui->timeDisplay->setText(QString("Time: %1").arg(elapsedTime));
}

void ApesTypegame::endGame() {
    timer->stop();
    ui->inputField->setEnabled(false);

    QTime endTime = QTime::currentTime();
    int elapsedTime = startTime.msecsTo(endTime) / 1000;

    ui->resultDisplay->setText(QString("You finished in %1 seconds!\nMistakes: %2")
                                   .arg(elapsedTime)
                                   .arg(mistakeCount));
}



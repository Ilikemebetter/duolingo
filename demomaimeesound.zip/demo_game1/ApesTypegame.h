#ifndef APESTYPEGAME_H
#define APESTYPEGAME_H

#include <QDialog>
#include <QTimer>
#include <QTime>
#include <QStringList>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include "ui_ApesTypegame.h"
//#include <QMediaPlayer>
//#include <QAudioOutput>


QT_BEGIN_NAMESPACE
namespace Ui { class ApesTypegame; }
QT_END_NAMESPACE

class ApesTypegame : public QDialog {  // เปลี่ยนจาก QWidget เป็น QDialog
    Q_OBJECT

public:
    explicit ApesTypegame(QWidget *parent = nullptr);  // เพิ่ม explicit และเปลี่ยนให้ตรงกับ QDialog
    ~ApesTypegame();

private slots:
    void startGame();
    void checkInput(const QString &text);
    void updateTimer();
    void endGame();

private:
    Ui::ApesTypegame *ui;
    QTimer *timer;
    QTime startTime;
    QStringList texts;
    QString currentText;
    int mistakeCount;
    //QMediaPlayer *bgSound;
    //QAudioOutput *audioOutput;
};

#endif // APESTYPEGAME_H

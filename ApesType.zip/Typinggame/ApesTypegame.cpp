#include "ApesTypegame.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QTime>
#include <QTimer>
#include <QStringList>
#include <QDebug>
#include <cstdlib>
#include <ctime>
#include <QFile>
#include <QTextStream>

TypingGame::TypingGame(QWidget *parent) : QWidget(parent) {
    srand(time(0)); // ตั้งค่า seed สำหรับ rand

    // อ่านคำศัพท์จากไฟล์ CSV
    QFile file(":/vocabulary_list.csv"); // ไฟล์อยู่ใน resources
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine();
            texts << line; // เพิ่มคำศัพท์ลงในลิสต์
        }
        file.close();
    } else {
        QMessageBox::warning(this, tr("Error"), tr("Failed to open CSV file!"));
    }

    setFixedSize(900, 600); // ตั้งค่าขนาดหน้าต่าง
    setupUI();
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &TypingGame::updateTimer);
}

void TypingGame::setupUI() {
    QVBoxLayout *layout = new QVBoxLayout(this);

    // ข้อความที่ต้องพิมพ์
    textDisplay = new QLabel("Press Start to begin!", this);
    textDisplay->setAlignment(Qt::AlignCenter);
    textDisplay->setStyleSheet("font-size: 24px; font-weight: bold;");
    layout->addWidget(textDisplay);

    // ช่องป้อนข้อมูล
    inputField = new QLineEdit(this);
    inputField->setEnabled(false);
    inputField->setStyleSheet("font-size: 20px; padding: 10px;");
    layout->addWidget(inputField);

    // แสดงเวลา
    timerDisplay = new QLabel("Time: 0", this);
    timerDisplay->setAlignment(Qt::AlignCenter);
    timerDisplay->setStyleSheet("font-size: 20px;");
    layout->addWidget(timerDisplay);

    // แสดงจำนวนครั้งที่ผิด และ ใช้เวลาเทา
    resultDisplay = new QLabel(this);
    resultDisplay->setAlignment(Qt::AlignCenter);
    resultDisplay->setStyleSheet("font-size: 20px; color: green;");
    layout->addWidget(resultDisplay);

    // ปุ่ม Start
    startButton = new QPushButton("Start", this);
    startButton->setStyleSheet("font-size: 20px; padding: 15px; background-color: #4CAF50; color: white;");
    layout->addWidget(startButton);

    connect(startButton, &QPushButton::clicked, this, &TypingGame::startGame);
    connect(inputField, &QLineEdit::textChanged, this, &TypingGame::checkInput);

    setLayout(layout);
}

void TypingGame::startGame() {
    if (texts.isEmpty()) {
        QMessageBox::warning(this, tr("Error"), tr("No words available!"));
        return;
    }

    int randomIndex = rand() % texts.size(); // สุ่มคำศัพท์
    currentText = texts[randomIndex];
    textDisplay->setText(currentText); // แสดงคำศัพท์บนหน้าจอ
    inputField->setText("");
    inputField->setEnabled(true);
    inputField->setFocus();
    resultDisplay->clear();
    mistakeCount = 0;

    startTime = QTime::currentTime();
    timer->start(100);
}

void TypingGame::checkInput(const QString &text) {
    if (text == currentText) {
        endGame();
    } else {
        if (currentText.startsWith(text)) {
            inputField->setStyleSheet("font-size: 20px; padding: 10px; color: green;");
        } else {
            inputField->setStyleSheet("font-size: 20px; padding: 10px; color: red;");
            mistakeCount++;
        }
    }
}

void TypingGame::endGame() {
    timer->stop();
    inputField->setEnabled(false);

    QTime endTime = QTime::currentTime();
    int elapsedTime = startTime.msecsTo(endTime) / 1000;

    // แสดงผลลัพธ์
    resultDisplay->setText(QString("You finished in %1 seconds!\nMistakes: %2")
                               .arg(elapsedTime)
                               .arg(mistakeCount));
}

void TypingGame::updateTimer() {
    int elapsedTime = startTime.msecsTo(QTime::currentTime()) / 1000;
    timerDisplay->setText(QString("Time: %1").arg(elapsedTime));
}

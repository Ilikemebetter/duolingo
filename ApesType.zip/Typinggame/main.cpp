#include <QApplication>
#include "ApesTypegame.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    TypingGame game;
    game.show();
    return app.exec();
}

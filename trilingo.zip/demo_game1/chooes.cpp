#include "chooes.h"
#include "ui_chooes.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QRandomGenerator>
#include <Qtimer>
#include <QInputDialog>
#include "dialog.h"


Chooes::Chooes(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Chooes)
    , wrongAnswersCount(0) //เริ่มนับจนข้อที่0
{
    ui->setupUi(this);
    // countdownSound = new QMediaPlayer(this);
    // audioOutput = new QAudioOutput(this);
    // countdownSound->setAudioOutput(audioOutput);
    // countdownSound->setSource(QUrl("qrc:/bgtrack/bgchoose.ogg"));
    // audioOutput->setVolume(0.7); // ตั้งระดับเสียง
    // countdownSound->play();


    bool ok;
    int userTime = QInputDialog::getInt(this, "ตั้งเวลา", "ระบุเวลาทั้งหมด (วินาที):", 30, 10, 300, 1, &ok);
    if (!ok) close();  // ถ้าผู้ใช้กดยกเลิก ให้ปิดโปรแกรม

    timeRemaining = userTime;  // กำหนดเวลา

    // ตั้งค่า Timer
    quizTimer = new QTimer(this);
    connect(quizTimer, &QTimer::timeout, this, &Chooes::updateTimer);
    quizTimer->start(1000);  // นับถอยหลังทุก 1 วินาที

    loadQuestionsFromCSV(); // โหลดคำถาม
    generateQuestion(); // แสดงคำถามแรก

    // เชื่อมปุ่มกับ slot
    connect(ui->btnOption1, &QPushButton::clicked, this, &Chooes::checkAnswer);
    connect(ui->btnOption2, &QPushButton::clicked, this, &Chooes::checkAnswer);
    connect(ui->btnOption3, &QPushButton::clicked, this, &Chooes::checkAnswer);
    connect(ui->btnOption4, &QPushButton::clicked, this, &Chooes::checkAnswer);
}

Chooes::~Chooes()
{
    delete ui;
    //delete countdownSound;
    //delete audioOutput;
}

void Chooes::loadQuestionsFromCSV() {
    QString filePath = QCoreApplication::applicationDirPath() + "/DataUser/" + Dialog::loggedInUser + ".csv";

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "ไม่สามารถเปิดไฟล์ vocabulary.csv ได้!");
        return;
    }

    QTextStream in(&file);
    bool firstLine = true;
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (firstLine) { // ข้ามบรรทัดแรก (header)
            firstLine = false;
            continue;
        }
        QStringList parts = line.split(',');
        if (parts.size() == 2) {
            vocabularyList.append(qMakePair(parts[0].trimmed(), parts[1].trimmed()));
        }
    }
    file.close();
}

// สุ่มคำถามใหม่
void Chooes::generateQuestion()
{
    if (vocabularyList.size() < 4) {
        QMessageBox::warning(this, "Error", "Not enough words in vocabulary.csv");
        return;
    }

    int correctIndex = QRandomGenerator::global()->bounded(vocabularyList.size());
    QPair<QString, QString> correctWord = vocabularyList[correctIndex];

    currentQuestion.meaning = correctWord.second;
    currentQuestion.options.clear();

    QVector<int> usedIndices;
    usedIndices.append(correctIndex);

    while (currentQuestion.options.size() < 3) {
        int randomIndex = QRandomGenerator::global()->bounded(vocabularyList.size());
        if (!usedIndices.contains(randomIndex)) {
            currentQuestion.options.append(vocabularyList[randomIndex].first);
            usedIndices.append(randomIndex);
        }
    }

    // สุ่มตำแหน่งของคำตอบที่ถูกต้อง
    int correctPosition = QRandomGenerator::global()->bounded(4);
    currentQuestion.correctIndex = correctPosition;
    currentQuestion.options.insert(correctPosition, correctWord.first);

    // แสดงคำถามบน UI
    ui->lblQuestion->setText(currentQuestion.meaning);
    ui->btnOption1->setText(currentQuestion.options[0]);
    ui->btnOption2->setText(currentQuestion.options[1]);
    ui->btnOption3->setText(currentQuestion.options[2]);
    ui->btnOption4->setText(currentQuestion.options[3]);

    ui->lblResult->clear();
}

// ตรวจสอบคำตอบ
void Chooes::checkAnswer()

{
    // ปิดการใช้งานปุ่มตัวเลือกทันที เพื่อป้องกันการคลิกซ้ำ
    ui->btnOption1->setEnabled(false);
    ui->btnOption2->setEnabled(false);
    ui->btnOption3->setEnabled(false);
    ui->btnOption4->setEnabled(false);

    QPushButton *clickedButton = qobject_cast<QPushButton*>(sender());
    if (!clickedButton) return;

    int selectedIndex = -1;
    if (clickedButton == ui->btnOption1) selectedIndex = 0;
    else if (clickedButton == ui->btnOption2) selectedIndex = 1;
    else if (clickedButton == ui->btnOption3) selectedIndex = 2;
    else if (clickedButton == ui->btnOption4) selectedIndex = 3;

    if (selectedIndex == -1) return;

    if (selectedIndex == currentQuestion.correctIndex) {
        ui->lblResult->setText("✅ Correct!");
    } else {
        ui->lblResult->setText(QString("❌ Wrong! Correct answer: %1")
                                   .arg(currentQuestion.options[currentQuestion.correctIndex]));
        wrongAnswersCount++;  // เพิ่มจำนวนข้อที่ผิด
    }

    QTimer::singleShot(1500, this, &Chooes::nextQuestion);
}

// ไปยังคำถามถัดไป
void Chooes::nextQuestion()
{
    if (timeRemaining <= 0) return;
    generateQuestion();
    ui->btnOption1->setEnabled(true);
    ui->btnOption2->setEnabled(true);
    ui->btnOption3->setEnabled(true);
    ui->btnOption4->setEnabled(true);

}

// อัปเดตเวลาและตรวจสอบว่าหมดเวลา
void Chooes::updateTimer()
{
    timeRemaining--;
    ui->lblTimeRemaining->setText(QString("Time Left: %1 sec").arg(timeRemaining));

    if (timeRemaining <= 0) {
        quizTimer->stop();
        // countdownSound->stop(); // หยุดเสียงตอนหมดเวลา

        // สร้าง QDialog เป็นหน้าต่างแจ้งเตือน
        QDialog *timeUpDialog = new QDialog(this);
        timeUpDialog->setFixedSize(1200, 800);
        timeUpDialog->setWindowTitle("Time's Up!");

        // ตั้งค่าภาพพื้นหลัง
        QLabel *backgroundLabel = new QLabel(timeUpDialog);
        QPixmap backgroundPixmap(":/bgflashc/bgscore.png"); // ใส่ path ของภาพที่ต้องการ
        if (backgroundPixmap.isNull()) {
            qDebug() << "❌ ไม่สามารถโหลดภาพพื้นหลังได้!";
        } else {
            qDebug() << "✅ โหลดภาพพื้นหลังสำเร็จ!";
        }
        backgroundLabel->setPixmap(backgroundPixmap);
        backgroundLabel->setScaledContents(true);
        backgroundLabel->setGeometry(0, 0, 1200, 800);

        // สร้าง QLabel สำหรับข้อความแจ้งเตือน
        QLabel *messageLabel = new QLabel(timeUpDialog);
        messageLabel->setText(QString("<h2 style='color:black;'>Time's up</h2>"
                                      "<h2 style='color:black;'>Incorrect : %1 </h2>")
                                  .arg(wrongAnswersCount));
        messageLabel->setAlignment(Qt::AlignCenter);
        messageLabel->setStyleSheet("font-size: 30px; font-weight: bold; font-family: 'Courier New';");
        messageLabel->setGeometry(520, 270, 400, 200);

        // สร้าง QVBoxLayout สำหรับจัดวางปุ่ม
        //messageLabel->setGeometry(520, 270, 400, 200); // ตั้งค่าตำแหน่งและขนาดเอง

        // สร้างปุ่มปิดเกม
        QPushButton *closeButton = new QPushButton("", timeUpDialog);
        closeButton->setStyleSheet(
            "background-image: url(:/bgmenu/btnmenurezied.png);"
            "border: none;"
            "background-repeat: no-repeat;"
            "background-position: center;"
            );

        // กำหนดขนาดของปุ่มให้ตรงกับภาพ
        QPixmap btnPixmap(":/bgmenu/btnmenurezied.png");
        closeButton->setFixedSize(btnPixmap.size());

        //ตำแแหน่งปุ่ม
        closeButton->setGeometry(860, 630, btnPixmap.width(), btnPixmap.height());

        // เชื่อมต่อปุ่มกับฟังก์ชันปิดเกม
        connect(closeButton, &QPushButton::clicked, this, &Chooes::closeGame);


        // แสดงหน้าต่าง
        timeUpDialog->exec();

        close(); // ปิดหน้าต่างหลัก
    }
}
void Chooes::closeGame()
{
    QApplication::quit(); // ปิดแอปพลิเคชัน
}

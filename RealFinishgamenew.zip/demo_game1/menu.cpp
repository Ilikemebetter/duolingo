#include "menu.h"
#include "ui_menu.h"
#include <QMessageBox>
#include <QDebug>

Menu::Menu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Menu),
    chooesGame(nullptr),
    FlashcardGame(nullptr),
    ApesTypeGame(nullptr)
{
    ui->setupUi(this);
    setFixedSize(1200, 800); // ตั้งค่าขนาดหน้าต่าง
    qDebug() << "Menu Created"; //debug menu page
    connect(ui->BtnToGameChoose, &QPushButton::clicked, this, &Menu::on_BtnToGameChoose_clicked);
    connect(ui->BtnToGameFlashcard, &QPushButton::clicked, this, &Menu::on_BtnToGameFlashcard_clicked);
    connect(ui->BtnToGameApestype, &QPushButton::clicked, this, &Menu::on_BtnToGameApestype_clicked);
}


Menu::~Menu()
{
    delete ui;
}


void Menu::on_BtnToGameChoose_clicked()
{
    if (chooesGame) {
        delete chooesGame;  // ลบ instance เดิมก่อน
    }
    chooesGame = new Chooes(this); // สร้างใหม่
    chooesGame->show();
}

void Menu::on_BtnToGameFlashcard_clicked()
{
    if (!FlashcardGame) {
        // สร้าง flashcardinput โดยไม่ระบุ parent
        FlashcardGame = new FlashcardInput(nullptr);
        // ตั้งค่าให้เป็น modal window
        FlashcardGame->setWindowModality(Qt::ApplicationModal);
        connect(FlashcardGame, &FlashcardInput::destroyed, this, [=]() {
            FlashcardGame = nullptr;
        });
    }
    FlashcardGame->show();
}


void Menu::on_BtnToGameApestype_clicked()
{
    if (!ApesTypeGame) {  // ถ้ายังไม่ได้สร้าง ให้สร้างขึ้นมา
        ApesTypeGame = new ApesTypegame(this);
    }
    ApesTypeGame->show();  // เปิดหน้าของเกมQMessageBox::information(this, "Game 3","ได้แล้ว");
}


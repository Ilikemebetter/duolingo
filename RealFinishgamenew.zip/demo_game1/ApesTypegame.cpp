#include "ApesTypegame.h"
#include "ui_ApesTypegame.h"
#include <QCoreApplication>
#include <QMessageBox>
#include <QTimer>
#include <QDebug>
#include <cstdlib>
#include <ctime>
#include <QFile>
#include <QKeyEvent>

ApesTypegame::ApesTypegame(QWidget *parent) : QDialog(parent)
    , ui(new Ui::ApesTypegame)
{
    ui->setupUi(this);
    setFixedSize(1200, 800); // ตั้งค่าขนาดหน้าต่าง
    srand(time(0)); // ตั้งค่า seed สำหรับ rand
    countdownTime = 30; // ตั้งค่าเริ่มต้น 30 วินาที

    // bgSound = new QMediaPlayer(this);
    // audioOutput = new QAudioOutput(this);
    // bgSound->setAudioOutput(audioOutput);
    // bgSound->setSource(QUrl("qrc:/bgtrack/fight_looped.ogg"));
    // audioOutput->setVolume(0.7); // ตั้งระดับเสียง
    // bgSound->play();

    // ปิดช่องกรอกข้อความตั้งแต่เริ่มต้น
    ui->inputField->setEnabled(false); // ปิดช่องกรอกข้อความเมื่อเริ่มต้น

    // อ่านคำศัพท์จากไฟล์ CSV
    QString filePath = QCoreApplication::applicationDirPath() + "/vocabulary_list.csv";
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            texts << in.readLine();
            //QString line = in.readLine();
            //texts << line; // เพิ่มคำศัพท์ลงในลิสต์
        }
        file.close();
    } else {
        QMessageBox::warning(this, tr("Error"), tr("Failed to open CSV file!"));
    }
    connect(ui->startButton, &QPushButton::clicked, this, &ApesTypegame::startGame);
    connect(ui->inputField, &QLineEdit::textChanged, this, &ApesTypegame::checkInput);
    // ตั้งค่า Timer
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &ApesTypegame::updateTimer);

}

ApesTypegame::~ApesTypegame() {
    delete ui;  //  ลบ ui เมื่อปิด Dialog
    //delete bgSound;
    //delete audioOutput;
}

void ApesTypegame::startGame() {
    if (texts.isEmpty()) {
        QMessageBox::warning(this, tr("Error"), tr("No words available!"));
        return;
    }

    // รับค่าจาก timeSelector และตั้งค่าถอยหลัง
    countdownTime = ui->timeSelector->value();
    ui->timerDisplay_2->setText(QString("Time: %1s").arg(countdownTime));

    // เริ่มต้นด้วยคำแรกจาก texts
    int randomIndex = rand() % texts.size();
    currentText = texts[randomIndex];
    ui->textDisplay->setText(currentText);
    ui->inputField->setText("");
    ui->inputField->setEnabled(true);
    ui->inputField->setFocus();
    ui->resultDisplay->clear();
    ui->accuracyDisplay->clear();

    mistakeCount = 0;
    correctChars = 0;
    totalTypedChars = 0;

    // ปิดปุ่ม Start เมื่อเกมเริ่ม
    ui->startButton->setEnabled(false);

    // เปิดช่องกรอกข้อความเมื่อเกมเริ่ม
    ui->inputField->setEnabled(true);  // เปิดให้พิมพ์เมื่อเริ่มเกม

    timer->start(1000); // เริ่มจับเวลา
}


void ApesTypegame::checkInput(const QString &text) {

    if (!ui->inputField->isEnabled()) {
        return; // ไม่ให้ทำงานถ้ายังไม่ได้เปิดใช้งานช่องกรอกข้อความ
    }

    totalTypedChars++; // เพิ่มตัวนับจำนวนตัวอักษรที่พิมพ์ทั้งหมด

    if (text == currentText) {
        ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: green;");

        // เมื่อพิมพ์คำถูกต้องแล้ว ให้สุ่มคำใหม่จาก texts
        int randomIndex = rand() % texts.size();
        currentText = texts[randomIndex];
        ui->textDisplay->setText(currentText); // แสดงคำใหม่
        ui->inputField->setText("");          // เคลียร์ช่องกรอกข้อความ
        ui->inputField->setFocus();           // ตั้งให้ช่องกรอกข้อความเป็นโฟกัสใหม่

        // เพิ่มคะแนนที่ถูกต้อง
        correctChars += text.length(); // เพิ่มตัวอักษรที่ถูกต้อง
    } else {
        if (currentText.startsWith(text)) {
            ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: green;");
            correctChars = text.length(); // นับจำนวนตัวอักษรถูกต้อง
        } else {
            ui->inputField->setStyleSheet("font-size: 20px; padding: 10px; color: red;");
            mistakeCount++;
        }
    }

    // คำนวณ accuracy ทุกครั้งหลังจากพิมพ์ข้อความ
    double acc = (totalTypedChars > 0) ? ((double)correctChars / totalTypedChars) * 100 : 0;
    ui->accuracyDisplay->setText(QString("Accuracy: %1%").arg(acc, 0, 'f', 2)); // แสดง accuracy
}


void ApesTypegame::updateTimer() {
    countdownTime--; // ลดเวลาถอยหลัง
    ui->timerDisplay_2->setText(QString("Time: %1s").arg(countdownTime));

    if (countdownTime <= 0) {
        endGame(); // จบเกมเมื่อหมดเวลา
    }
}


void ApesTypegame::endGame() {
    timer->stop();
    ui->inputField->setEnabled(false);
    ui->startButton->setEnabled(true);  // เปิดปุ่ม Start

    // คำนวณ accuracy เมื่อเกมจบ
    double acc = (totalTypedChars > 0) ? ((double)correctChars / totalTypedChars) * 100 : 0;

    ui->resultDisplay->setText(QString("Game Over!\nMistakes: %1").arg(mistakeCount));
    ui->accuracyDisplay->setText(QString("Accuracy: %1%").arg(acc, 0, 'f', 2)); // แสดง accuracy เมื่อเกมจบ
}




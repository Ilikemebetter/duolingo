#include <QApplication>
#include "flashcardinput.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    FlashcardInput w;
    w.show();
    return a.exec();
}

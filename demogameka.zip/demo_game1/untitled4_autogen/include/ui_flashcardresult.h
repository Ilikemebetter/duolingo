/********************************************************************************
** Form generated from reading UI file 'flashcardresult.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FLASHCARDRESULT_H
#define UI_FLASHCARDRESULT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FlashcardResult
{
public:
    QPushButton *menuButton;
    QPushButton *nextGameButton;
    QLabel *correctLabel;
    QLabel *incorrectLabel;
    QLabel *label_3;
    QLabel *label_4;

    void setupUi(QWidget *FlashcardResult)
    {
        if (FlashcardResult->objectName().isEmpty())
            FlashcardResult->setObjectName("FlashcardResult");
        FlashcardResult->resize(640, 480);
        menuButton = new QPushButton(FlashcardResult);
        menuButton->setObjectName("menuButton");
        menuButton->setGeometry(QRect(70, 320, 80, 24));
        nextGameButton = new QPushButton(FlashcardResult);
        nextGameButton->setObjectName("nextGameButton");
        nextGameButton->setGeometry(QRect(190, 320, 80, 24));
        correctLabel = new QLabel(FlashcardResult);
        correctLabel->setObjectName("correctLabel");
        correctLabel->setGeometry(QRect(70, 230, 71, 16));
        incorrectLabel = new QLabel(FlashcardResult);
        incorrectLabel->setObjectName("incorrectLabel");
        incorrectLabel->setGeometry(QRect(70, 260, 71, 16));
        label_3 = new QLabel(FlashcardResult);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(50, 120, 171, 16));
        label_4 = new QLabel(FlashcardResult);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(50, 140, 171, 16));

        retranslateUi(FlashcardResult);

        QMetaObject::connectSlotsByName(FlashcardResult);
    } // setupUi

    void retranslateUi(QWidget *FlashcardResult)
    {
        FlashcardResult->setWindowTitle(QCoreApplication::translate("FlashcardResult", "Form", nullptr));
        menuButton->setText(QCoreApplication::translate("FlashcardResult", "Menu", nullptr));
        nextGameButton->setText(QCoreApplication::translate("FlashcardResult", "Next Game !", nullptr));
        correctLabel->setText(QCoreApplication::translate("FlashcardResult", "Correct    : X", nullptr));
        incorrectLabel->setText(QCoreApplication::translate("FlashcardResult", "Incorrect : Y", nullptr));
        label_3->setText(QCoreApplication::translate("FlashcardResult", " Very Very Good 1 pound fish", nullptr));
        label_4->setText(QCoreApplication::translate("FlashcardResult", " Very Very Sheep 1 pound fish", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FlashcardResult: public Ui_FlashcardResult {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FLASHCARDRESULT_H

/********************************************************************************
** Form generated from reading UI file 'menu.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENU_H
#define UI_MENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Menu
{
public:
    QLabel *label;
    QPushButton *BtnToGameFlashcard;
    QPushButton *BtnToGameChoose;
    QPushButton *BtnToGameApestype;

    void setupUi(QWidget *Menu)
    {
        if (Menu->objectName().isEmpty())
            Menu->setObjectName("Menu");
        Menu->resize(877, 505);
        label = new QLabel(Menu);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 0, 881, 511));
        label->setStyleSheet(QString::fromUtf8("border-image: url(:/res/Duolinga.png);"));
        BtnToGameFlashcard = new QPushButton(Menu);
        BtnToGameFlashcard->setObjectName("BtnToGameFlashcard");
        BtnToGameFlashcard->setGeometry(QRect(310, 110, 251, 81));
        BtnToGameFlashcard->setStyleSheet(QString::fromUtf8("font: 700 18pt \"Leelawadee UI\";"));
        BtnToGameChoose = new QPushButton(Menu);
        BtnToGameChoose->setObjectName("BtnToGameChoose");
        BtnToGameChoose->setGeometry(QRect(310, 210, 251, 81));
        BtnToGameChoose->setStyleSheet(QString::fromUtf8("font: 700 18pt \"Leelawadee UI\";"));
        BtnToGameApestype = new QPushButton(Menu);
        BtnToGameApestype->setObjectName("BtnToGameApestype");
        BtnToGameApestype->setGeometry(QRect(310, 310, 251, 81));
        BtnToGameApestype->setStyleSheet(QString::fromUtf8("font: 700 18pt \"Leelawadee UI\";"));

        retranslateUi(Menu);

        QMetaObject::connectSlotsByName(Menu);
    } // setupUi

    void retranslateUi(QWidget *Menu)
    {
        Menu->setWindowTitle(QCoreApplication::translate("Menu", "Form", nullptr));
        label->setText(QString());
        BtnToGameFlashcard->setText(QCoreApplication::translate("Menu", "FLASH CARD", nullptr));
        BtnToGameChoose->setText(QCoreApplication::translate("Menu", "CHOOSE", nullptr));
        BtnToGameApestype->setText(QCoreApplication::translate("Menu", "APES TYPE", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Menu: public Ui_Menu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENU_H

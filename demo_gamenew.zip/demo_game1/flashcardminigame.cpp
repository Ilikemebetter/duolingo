#include "flashcardminigame.h"
#include "ui_flashcardminigame.h"
#include "flashcardresult.h"
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>
#include <QMessageBox>
#include <QRandomGenerator>
#include <QTimer>
#include <QPushButton>
#include <algorithm>

FlashcardMiniGame::FlashcardMiniGame(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::flashcardminigame),
    currentRound(0),
    correctCount(0),
    wrongCount(0)
{
    ui->setupUi(this);
    loadFlashcards();
    if (flashcards.isEmpty()) {
        QMessageBox::critical(this, "Error", "No flashcards available. Please add some words first.");
        close();
        return;
    }
    connect(ui->NextButton, &QPushButton::clicked, this, &FlashcardMiniGame::handleNext);
    setupRound();
}

FlashcardMiniGame::~FlashcardMiniGame()
{
    delete ui;
}

void FlashcardMiniGame::loadFlashcards()
{
    QString filePath = QCoreApplication::applicationDirPath() + "/vocabulary_list.csv";
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty())
            continue;
        QStringList parts = line.split(",");
        if (parts.size() >= 2)
            flashcards.append(qMakePair(parts[1].trimmed(), parts[0].trimmed())); // สลับตำแหน่ง word และ meaning
    }
    file.close();
}

void FlashcardMiniGame::setupRound()
{
    ui->gameProgress->setText(QString("Round %1 of %2").arg(currentRound + 1).arg(totalRounds));

    int idx = QRandomGenerator::global()->bounded(flashcards.size());
    QPair<QString, QString> currentCard = flashcards.at(idx);
    ui->meaningLabel->setText(currentCard.first); // เปลี่ยน QLabel นี้ให้แสดงความหมายแทน
    correctAnswer = currentCard.second;

    ui->Writethisline->clear();
    ui->feedbackLabel->setText("");
}

void FlashcardMiniGame::handleNext()
{
    ui->NextButton->setEnabled(false);

    QString userAnswer = ui->Writethisline->text().trimmed();
    if (userAnswer.compare(correctAnswer, Qt::CaseInsensitive) == 0) {
        correctCount++;
        ui->feedbackLabel->setText("✔ Correct!");
    } else {
        wrongCount++;
        ui->feedbackLabel->setText("✘ Incorrect! Correct answer: " + correctAnswer);
    }

    currentRound++;

    QTimer::singleShot(1000, this, [this]() {
        if (currentRound >= totalRounds) {
            FlashcardResult *result = new FlashcardResult(correctCount, wrongCount);
            result->show();
            this->close();
        } else {
            setupRound();
            ui->NextButton->setEnabled(true);
        }
    });
}
